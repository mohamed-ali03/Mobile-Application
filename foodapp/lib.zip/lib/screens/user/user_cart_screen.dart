import 'package:flutter/material.dart';
import 'package:foodapp/models/order%20item%20model/order_item_model.dart';
import 'package:foodapp/models/order%20model/order_model.dart';
import 'package:foodapp/providers/order_provider.dart';
import 'package:foodapp/screens/user/widgets/order_card.dart';
import 'package:foodapp/screens/user/widgets/unsynced_items.dart';
import 'package:provider/provider.dart';

class UserCartScreen extends StatefulWidget {
  const UserCartScreen({super.key});

  @override
  State<UserCartScreen> createState() => _UserCartScreenState();
}

class _UserCartScreenState extends State<UserCartScreen>
    with TickerProviderStateMixin {
  late TabController tabController;

  @override
  void initState() {
    tabController = TabController(length: 3, vsync: this);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: _buildAppBar(), body: _buildBody());
  }

  AppBar _buildAppBar() {
    return AppBar(
      title: const Text('Cart'),
      leading: IconButton(
        onPressed: () {
          Navigator.pop(context);
        },
        icon: const Icon(Icons.arrow_back),
      ),
      bottom: TabBar(
        controller: tabController,
        tabs: [
          Tab(text: 'Unordered'),
          Tab(text: 'Processing'),
          Tab(text: 'Delivered'),
        ],
      ),
    );
  }

  Widget _buildBody() {
    return Consumer<OrderProvider>(
      builder: (context, value, child) {
        if (value.isLoading) {
          return Center(child: CircularProgressIndicator());
        }

        if (value.error != null) {
          return Center(child: Text('error in geting orders'));
        }

        return TabBarView(
          controller: tabController,
          children: [
            UnsyncedItems(
              orderItems: value.orderItems
                  .where((item) => item.synced == false)
                  .toList(),
            ),
            _ShowOrders(
              orderItems: value.orderItems,
              orders: value.orders
                  .where((order) => order.status.toLowerCase() != 'delivered')
                  .toList(),
            ),
            _ShowOrders(
              orderItems: value.orderItems,
              orders: value.orders
                  .where((order) => order.status.toLowerCase() == 'delivered')
                  .toList(),
            ),
          ],
        );
      },
    );
  }
}

class _ShowOrders extends StatelessWidget {
  final List<OrderItemModel> orderItems;
  final List<OrderModel> orders;
  const _ShowOrders({required this.orderItems, required this.orders});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: orders.length,
      itemBuilder: (context, index) => OrderCard(
        order: orders[index],
        orderItems: orderItems
            .where((orderItem) => orderItem.orderId == orders[index].orderId)
            .toList(),
      ),
    );
  }
}
