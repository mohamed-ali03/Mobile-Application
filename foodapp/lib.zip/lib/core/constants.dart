// User roles
enum Role { user, staff, admin }

// Order statuses
enum OrderStatus { pending, accepted, preparing, done }
